export { default as HomeSlider } from "./homeSlider";
