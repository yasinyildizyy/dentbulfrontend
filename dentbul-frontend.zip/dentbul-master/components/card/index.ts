export { default as CardInfo } from "./cardInfo";
export { default as CardTreatment } from "./cardTreatment";
export { default as CardTestimonials } from "./cardTestimonials";
export { default as CardBlog } from "./cardBlog";
export { default as CardGallery } from "./cardGallery";
export { default as CardDoctor } from "./cardDoctor";
export { default as CardPatient } from "./cardPatient";
