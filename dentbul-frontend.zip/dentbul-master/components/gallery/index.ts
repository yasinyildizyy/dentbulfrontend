export { default as Gallery } from "./gallery";
