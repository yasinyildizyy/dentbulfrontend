export { default as MainSwiper } from "./mainSwiper";
