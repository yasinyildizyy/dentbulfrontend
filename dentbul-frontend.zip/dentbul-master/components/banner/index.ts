export { default as BannerJourney } from "./bannerJourney";
