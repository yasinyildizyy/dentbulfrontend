export { default as ArrowNext } from "./ArrowNext";
export { default as ArrowPrev } from "./ArrowPrev";
export { default as Check } from "./Check";
export { default as Whatsapp } from "./Whatsapp";
