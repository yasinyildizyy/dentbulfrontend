export { default as Footer } from "./footer";
