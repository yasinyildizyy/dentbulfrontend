export interface ITreatmentProps {
  page?: string;
  itemsPerPage?: string;
  pagination?: string;
  isShowHomepage?: string | any;
  order?: string;
  locale: string;
}
