export interface IBlogProps {
  parent?: string | any;
  order?: string | any;
  page?: string | any;
  itemsPerPage?: string | any;
  pagination?: string | any;
  locale?: string | any;
}
