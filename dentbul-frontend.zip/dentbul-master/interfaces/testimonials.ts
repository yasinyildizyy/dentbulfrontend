export interface ITestimonialsProps {
  page?: string;
  itemsPerPage?: string;
  pagination?: string;
  isShowHomepage?: string | any;
  order?: any;
  locale: string;
}
